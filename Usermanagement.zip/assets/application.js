(function ($) {

    // JS

}(jQuery));